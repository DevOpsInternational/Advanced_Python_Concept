#File Handeling Operation read operation
f=open("RandomModule.py","r")
d=f.read()
print(d)
f.close()
